# meandmyshadow_levelpack_akos
This level pack for the game [Me and My Shadow](http://meandmyshadow.sourceforge.net/) was created by Akos. He was 12 at the time of creation.
Enjoy!
